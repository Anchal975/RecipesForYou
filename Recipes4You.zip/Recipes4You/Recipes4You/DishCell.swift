//
//  DishCell.swift
//  Recipes4You
//
//  Created by mac air 2017 256 on 2020-12-03.
//

import UIKit

class DishCell: UITableViewCell {


    @IBOutlet weak var dishImg: UIImageView!
    @IBOutlet weak var dishName: UITextField!
    func dishCellSetup(dish:Dish){
        dishName.text=dish.DishName
        dishImg.image = UIImage(named: dish.Image)
    }
}
